import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Ashour on 11/6/2016.
 */
public class EmployeeTest {

    private Employee e;

    @Before
    public void setUp() throws Exception {
        e = new Employee(1337, "John Smith", "jsmith@gmail.com", 32);
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void getEmpID() throws Exception {

    }

    @Test
    public void getName() throws Exception {

        //assertEquals(expected, actual);
        assertEquals("John Smith", e.getName());
    }

    @Test
    public void getEmail() throws Exception {

    }

    @Test
    public void getAge() throws Exception {

        assertEquals(32, e.getAge());
    }

    @Test
    public void setEmpID() throws Exception {

    }

    @Test
    public void setName() throws Exception {

    }

    @Test
    public void setEmail() throws Exception {

    }



    @Test
    public void setAge() throws Exception {

    }

}