import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

/**
 * Created by Ashour on 11/6/2016.
 */
public class DriverTest {
    @Test
    public void main() throws Exception {

    }

    @Test
    public void getInfoFromFile() throws Exception {

        Driver d = new Driver();
        ArrayList<Employee> employeeArray = d.getInfoFromFile();
        assertEquals("Dale Reed", employeeArray.get(0).getName());
    }

}