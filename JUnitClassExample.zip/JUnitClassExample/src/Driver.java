import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class Driver {

    public static void main(String[] args){


    }

    /**
     *  A method that reads from a .csv file and stores the contents of the employee inside of an ArrayList
     * @return
     */
    public static ArrayList<Employee> getInfoFromFile(){

        ArrayList<Employee> employeesArray = new ArrayList<>(); // Create an ArrayList of Employee
        String csvFile = "addr.csv";    // Holds the name of file
        BufferedReader br = null;       // Creates an instance of the BufferedReader class
        String line;                    // Holds the line currently being read in by the BufferedReader
        String splitBy = ",";           // Used to parse the line by making a comma the delimiter


        try{

            br = new BufferedReader(new FileReader(csvFile));   // Hold the file in the buffer

            br.readLine();                                      // Reads in first line and doesn't use (header of file)

            while ((line = br.readLine()) != null){             // While we haven't reached the end of file

                String[] parsedLine = line.split(splitBy);      // Split the line read in using the comma as the delimiter
                if(parsedLine.length != 4)
                    throw new IOException("ERROR INSIDE FILE!");


                employeesArray.add(new Employee(Integer.parseInt(parsedLine[0]), // Add the employee's info read in into the ArrayList
                                   parsedLine[1], parsedLine[2], Integer.parseInt(parsedLine[3]) ));
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        finally {
            if (br != null){
                try {
                    br.close();
                }
                catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
        return employeesArray;
    }
}
