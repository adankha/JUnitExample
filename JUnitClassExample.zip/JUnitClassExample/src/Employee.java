/**
 * Created by Ashour on 11/6/2016.
 */
public class Employee {

    private int empID;
    private String name;
    private String email;
    private int age;

    public Employee(int empID, String name, String email, int age) {
        this.empID = empID;
        this.name = name;
        this.email = email;
        this.age = age;
    }


    public int getEmpID() {
        return empID;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getAge() {
        return age;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
